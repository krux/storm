from distutils.core import setup
setup(
    name="python-storm",
    version="0.8.2",
    packages=['storm'],
)
